# Text Detection > 2022-11-25 3:01pm
https://universe.roboflow.com/text-3f5xz/text-detection-e38ye

Provided by a Roboflow user
License: CC BY 4.0

